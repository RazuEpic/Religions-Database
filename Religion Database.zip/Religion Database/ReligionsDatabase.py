class Religion:
    def __init__(self, name, symbols, texts, beliefs, practices, gods, leaders, history) -> None:
        self.name = name
        self.symbols = symbols
        self.texts = texts
        self.beliefs = beliefs
        self.practices = practices
        self.gods = gods
        self.leaders = leaders
        self.history = history

    def __str__(self):
        return (f"""
Name: {self.name}
Symbols: {self.symbols}
Sacred Text: {self.texts}
Key Beliefs: {self.beliefs}
Practices / Rituals: {self.practices}
God: {self.gods}
Sacred Leaders: {self.leaders}
History / Sociology: {self.history}""")

    def from_file(self, filename):
        with open(filename, 'r') as file:
            lines = file.readlines()
        self.name = lines[0].strip()
        self.symbols = lines[1].strip()
        self.texts = lines[2].strip()
        self.beliefs = lines[3].strip()
        self.practices = lines[4].strip()
        self.gods = lines[5].strip()
        self.leaders = lines[6].strip()
        self.history = lines[7].strip()

    def to_file(self, filename):
        with open(filename, 'w') as file:
            file.write(f"{self.name}\n{self.symbols}\n{self.texts}\n{self.beliefs}\n{self.practices}\n{self.gods}\n{self.leaders}\n{self.history}")

Christianity = Religion("Christianity", "", "", "", "", "", "", "")
Christianity.from_file("Christianity.txt")

Islam = Religion("Islam", "", "", "", "", "", "", "")
Islam.from_file("Islam.txt")

Judaism = Religion("Judaism", "", "", "", "", "", "", "")
Judaism.from_file("Judaism.txt")

while True:
    choice = input("1) Christianity\n2) Islam\n3) Judaism\n4) Exit\n>> ")
    if choice == '1':
        print(Christianity)
    elif choice == '2':
        print(Islam)
    elif choice == '3':
        print(Judaism)
    elif choice == '4':
        print("Exiting the program.")
        break
    else:
        print("Invalid choice. Please select 1, 2, 3, or 4.")
